mkdir update
cd update
echo.> new.html
curl https://chuboithedev.github.io/updata.txt >> new.html
del newadditions.txt
curl https://chuboithedev.github.io/newadditions.txt >> newadditions.txt
pause